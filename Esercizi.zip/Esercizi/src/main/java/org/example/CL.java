package org.example;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CL {

    private static long timestamp;
    static int portNumer = 1234;
    static String ip = "127.0.0.1";
//    static Socket clientSocket = null;
    static Socket socket;
    static PrintWriter out;
    static InputStream in;
    static BufferedReader br;

    static {

    }

    public static void main(String[] args) {

        String data = new String();
        socket = openToServer();

        try {
            out = new PrintWriter(socket.getOutputStream(),true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (true) {

            try {
                data = br.readLine();
                processa(data);
            } catch (IOException e) {
                e.printStackTrace();
            }

//            System.out.println(clientSocket.getLocalAddress());
//
//            ClientHandler clientHandler = new ClientHandler(clientSocket);
//
//            new Thread(clientHandler).start();


        }

    }

    private static void write(String message){
        System.out.println(message);
//        out.println(message);
    }

    private static void processa(String data) {
        timestamp = System.currentTimeMillis();

        long arrivato = Long.parseLong(data.split(" ")[1].split(":")[0]);

        String separated[] = data.split(" ");

        String id = separated[separated.length - 1];

        long delay = timestamp - arrivato;

        if (delay > 300){
            write("CL" + id + " " + arrivato + ": HIGH DELAY " + delay);
        }
        else {
            write("CL" + id + ": MAX DELAY " + delay + "ms");
        }

    }

    static private Socket openToServer() {
        try {
            socket = new Socket(ip, portNumer);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            in = socket.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }

        br = new BufferedReader(
                new InputStreamReader(in)
        );

        return socket;
    }


}